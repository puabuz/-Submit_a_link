

function Error() {

  

    return (
      <div className="main">
  
      </div>
    );
  }
  
  
  export default Error;