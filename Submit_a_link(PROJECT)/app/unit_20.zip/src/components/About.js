

function About() {

  

  return (
    <div className="container btn_margin">
        <p className="">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut ad  qtinctio recusandae officia voluptas commodi cupiditate qtinctio recusandae officia voluptas commodi cupiditate qtinctio recusandae officia voluptas commodi cupiditate pariatur qtinctio recusa qtinctio recusandae officia voluptas commodi cupiditatendae officia volu qtinctio recusandae officia voluptas commodi cupiditateptas commodi cupiditate deleniti sed?</p>
    </div>
  );
}


export default About;