

function Footer() {

  

    return (
      <div className="main">
  
      </div>
    );
  }
  
  
  export default Footer;